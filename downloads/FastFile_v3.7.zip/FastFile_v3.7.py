import os
import shutil
#import pickle
import time
from pathlib import Path
import Run_Logo_Animation_optiotwo as playvid


#currentpath = "C:/"



#All errors that can occur in this programm
errorcodes = {
    "error422": "Error 422: Input not valid",
    "error404": "Error 404: Path not found",
    "error404_varFile": "Error 404: File not found",
    "error501_varFile": "Error501: The file could not be created. Maybe you misspelled something",
    "error501_varFolder": "Error 501: The folder could not be created. Maybe you misspelled something",
    "error403_varCreateFolder": "Error 403: You have no permission to delete folders containing content",
    "error423_varFile": "Error 423: This command does not work for folders.",
    "error423_varFolder": "Error 423: This command does not work for files",
    "error502_varFile": "Error 502: This file could not be pasted. Maybe try a different directory",
    "error502_varFolder": "Error 502: This folder could not be pasted. Maybe try a different directory",
    "error424_varFile": "Error 424: You need to copy something first",
    "error425": "Error 425: You need to mark a directory first",
    "error426": "Error 426: Not a valid ZIP File"
}


def setup_fastfile():
    print("Welcome to FastFile, the light-weight textbased file management system for Windows.")
    time.sleep(3)
    print("Please agree to the EULA (1) and the Privacy Policy (2) before continuing.")
    time.sleep(3)
    print("In the 'Enter action' input, write the following to choose your action:")
    print("1. Open the EULA, type --> 1")
    print("2. Open the Privacy Policy, type --> 2")
    print("3. Agree to the EULA, type --> agree 1")
    print("4. Agree to the Privacy Policy, type  --> agree 2")
    agreed_eula = False
    agreed_privacypolicy = False

 
    

    while True:

        setup_action = input("Enter action:")

        if setup_action.lower() == "agree 1":
            agreed_eula = True
            print("Agreed to the EULA of FastFile")

        elif setup_action.lower() == "agree 2":
            agreed_privacypolicy = True
            print("Agreed to the Privacy Policy of FastFile")

        elif setup_action == "1":
            eula_path = os.path.join(scriptdir.parent, "Fastfile Eula.pdf")
            os.startfile(eula_path)

        elif setup_action == "2":
            privacypolicy_path = os.path.join(scriptdir.parent, "Fastfile Privacy Policy.pdf")
            os.startfile(privacypolicy_path)

        else:
            print(errorcodes["error422"])

        if agreed_eula == True and agreed_privacypolicy == True:
            print("Thank you for accepting our Policies.")
            time.sleep(2.5)
            return True
            

copiedFile = None
copiedFile_Name = None
copiedFile_type = None
markedPath = None

scriptdir = Path(__file__)
default_path_store = os.path.join(scriptdir.parent, "FastFile_defaultpath.txt")

try:
    with open(default_path_store, "r") as f:
        currentpath = f.read()
        sorted(os.listdir(currentpath))
        print("FastFile")
        print("User data found")
        print("Loading...")
        playvid.play_video(os.path.join(scriptdir.parent, "FastFile-Animation4.mp4"))
        time.sleep(1)

except:
    print("FastFile")
    print("Loading...")
    playvid.play_video(os.path.join(scriptdir.parent, "FastFile-Animation4.mp4"))
    time.sleep(1)
    setup_complete = setup_fastfile()

    if setup_complete == True:
        with open(default_path_store, "w") as f:
            
            while True:
                print("What is your default starting path? (you can change it later using: 'changeDefaultPath')")
                currentpath = input("Enter: ")

                try:
                    sorted(os.listdir(currentpath))
                    f.write(currentpath)
                    print("Loading...")
                    time.sleep(3.5)
                    break
                except:
                    print(errorcodes["error404"])







#Display content in selected Folder

def displaydirectory(path):
    index = 0
    allfiles_in_directory = sorted(os.listdir(path))

    alloweddir = []
    print(currentpath)
    try:
        max_len = max(len(char) for char in allfiles_in_directory)
    except:
        print("Empty Folder")

    for name in allfiles_in_directory:

        joined_Name = os.path.join(currentpath, name)

        if os.path.isfile(joined_Name):
            extention = os.path.splitext(name)[1]

            try:
                alligned = name.ljust(max_len)
            except:
                pass
            print(index, alligned, "--> ", extention)

        elif os.path.isdir(joined_Name):

            try:
                alligned = name.ljust(max_len)
            except:
                pass
            print(index, alligned, "--> Folder")
            alloweddir.append(index)
        else:
            try:
                alligned = name.ljust(max_len)
            except:
                pass
            print(index, alligned, "--> unknown Object")
        index += 1



    

    #Classify command and preperation for data to give to the Command Parser
    accepted = 0

    while True:
        return_action = input("Enter action ")
        print("\n")

        if return_action.isdigit() == True: #included
            return_action = int(return_action)

            try:
                alloweddir.index(return_action)
                accepted = 1
                return "selectFolder", return_action
            
            except:
                return "selectFile", return_action
            


        elif return_action == "back" or return_action == "Back": #included
            accepted = 1
            return "back", return_action
        


        elif "add" in return_action: #included
            parts = return_action.split()

            try:
                #keyword = parts[0]
                parameter1 = parts[1] if len(parts[1]) >= 1 else None
                parameter2 = parts[2] if len(parts[2]) >= 1 else None
            except:
                print(errorcodes["error422"])

            if parameter1 != None and parameter2 != None:
                details = [parameter1, parameter2]
                return "add", details
            else:
                print(errorcodes["error422"])
                continue



        elif "delete" in return_action: #included
            parts = return_action.split()

            try:
                #keyword = parts[0]
                parameter1 = parts[1] if len(parts[1]) >= 1 else None
                parameter1 = int(parameter1)
            except:
                print(errorcodes["error422"])
                time.sleep(3)
                continue

            if parameter1 != None:
                return "delete", parameter1
            else:
                print(errorcodes["error422"])
                time.sleep(2)
                continue
        


        elif "rename" in return_action: #included
            parts = return_action.split()

            try:
                #keyword = parts[0]
                parameter1 = parts[1] if len(parts[1]) >= 1 else None
                parameter2 = parts[2] if len(parts[1]) >= 1 else None

                if parameter1 != None or parameter2 != None:
                    parameter1 = int(parameter1)
                    details = [parameter1, parameter2]
                    return "rename", details
                else:
                    print(errorcodes["error422"])
                    time.sleep(3)   

            except:
                print(errorcodes["error422"])
                time.sleep(2)
                continue



        elif "copy" in  return_action: #included
            parts = return_action.split()

            try:
                #keyword = parts[0]
                parameter1 = parts[1] if len(parts[1]) >= 1 else None
            
                if parameter1 != None:
                    parameter1 = int(parameter1)

                    if parameter1 not in alloweddir:
                        details = [parameter1, "file"]
                        return "copy", details
                    else:
                        details = [parameter1, "folder"]
                        return "copy", details
            except:
                print(errorcodes["error422"])
                time.sleep(2)
                

        elif "extract" in return_action: #included
            parts = return_action.split()

            try:
                #keyword = parts[0]
                parameter1 = parts[1] if len(parts[1]) >= 1 else None
            
                if parameter1 != None:
                    parameter1 = int(parameter1)

                    if parameter1 in alloweddir:
                        return "extract", parameter1
                    else:
                        print(errorcodes["error423_varFolder"])
                        time.sleep(2)
                else:
                    print(errorcodes["error422"])
                    time.sleep(2)
            except:
                print(errorcodes["error422"])
                time.sleep(2)
        
        elif "compress" in return_action: #included
            parts = return_action.split()

            try:
                #keyword = parts[0]
                parameter1 = parts[1] if len(parts[1]) >= 1 else None
                parameter2 = parts[2] if len(parts[2]) >= 1 else None

                if parameter1 != None and parameter2 != None:
                    parameter1 = int(parameter1)

                    if parameter1 in alloweddir:
                        details = [parameter1, parameter2]
                        return "zip", details
                    else:
                        print(errorcodes["error423_varFolder"])
                        time.sleep(2)
                else:
                    print(errorcodes["error422"])
                    time.sleep(2)
            except:
                print(errorcodes["error422"])
                time.sleep(2)
        
        elif "unpack" in return_action: #included

            parts = return_action.split()

            try:
                #keyword = parts[0]
                parameter1 = parts[1] if len(parts[1]) >= 1 else None
            
                if parameter1 != None:
                    parameter1 = int(parameter1)

                    if parameter1 not in alloweddir:
                        return "unzip", parameter1
                    else:
                        print(errorcodes["error423_varFile"])
                        time.sleep(2)
                else:
                    print(errorcodes["error422"])
                    time.sleep(2)
            except:
                print(errorcodes["error422"])
                time.sleep(2)


        elif return_action == "paste": #included
            return "paste", "paste"
        


        elif return_action == "move": #included
            return "move", "move"
        


        elif return_action == "changepath": #included
            return "changePath", return_action
        


        elif return_action == "changeDefaultPath": #included
            return "changeDefaultPath", return_action



        elif return_action == "markpath": #included
            return "markPath", return_action


        elif return_action == "marked": #included
            return "marked", return_action

        elif return_action == "exit" or return_action == "Exit":
            exit(1)



        else:
            print(errorcodes["error422"])
            time.sleep(3)

        if accepted == 1:
            break







# Functions for Command Parser
def open_file(path):
    os.startfile(path)


def create_file(path, name, extension):
    fullpath = os.path.join(path, f"{name}.{extension}")

    try:
        with open(fullpath, "wb"):
            return True
    except:
        return False


def create_folder(path, name):
    fullpath = os.path.join(path, name)

    try:
        os.mkdir(fullpath)
        return True
    except:
        return False

def delete_file(path, name):
    fullpath = os.path.join(path, name)
    print(fullpath)

    if os.path.isfile(fullpath):
        try:
            os.remove(fullpath)
            return True
        except:
            return False

    elif os.path.isdir(fullpath):
        try:
            os.rmdir(fullpath)
            return True
        except:
            return 2
    else:
        return False

def paste_file(sourcePath, name, type):
    destinationPath = currentpath + "/" + name
    
    if type == "file":
        try:
            shutil.copy(sourcePath, destinationPath)
        except:
            print(errorcodes["error502_varFile"])
            time.sleep(2)
    elif type == "folder":
        try:
            shutil.copytree(sourcePath, destinationPath)
        except:
            print(errorcodes["error502_varFolder"])
            time.sleep(2)


def move_file(sourcePath, name):
    destinationPath = currentpath + "/" + name
    try:
        shutil.move(sourcePath, destinationPath)
    except:
        print(errorcodes["error502_varFile"])
        time.sleep(2)
    
def extract_file(sourcePath, destinationPath):
    try:
        shutil.move(sourcePath, destinationPath)
        return True
    except:
        return False
    

def rename_file(path, name):
    oldPath = currentpath + "/" + path
    newPath = currentpath + "/" + name

    try:
        os.rename(oldPath, newPath)
        print(f"The name of {path} was successfully changed to {name}")
        time.sleep(2)
    except:
        print(errorcodes["error422"])
        time.sleep(2)

def create_zip(path, name):
    try:
        folder = currentpath + "/" + name
        output = shutil.make_archive(folder, "zip", path)
        return True
    except:
        return False
    
def unzip_file(zipfile, name):
    try:
        name = name + " - Unpacked"
        extract_to_folder = create_folder(currentpath, name)

        if extract_to_folder == True:
            fullpath = os.path.join(currentpath, name)
            shutil.unpack_archive(zipfile, fullpath)
        else:
            print(errorcodes["error422"])

        return True
    except:
        return False
    

# Command Parser
while True:
    actiontype, actiondetails = displaydirectory(currentpath)

    if actiontype == "selectFolder":
        files_in_path = sorted(os.listdir(currentpath))

        try:
            selectedFolder = files_in_path[actiondetails]
            currentpath = currentpath + "/"  + selectedFolder

        except:
            print(errorcodes["error404"])
            time.sleep(2)

       

    elif actiontype == "selectFile":
        files_in_path = sorted(os.listdir(currentpath))

        try:
            selectedFile = files_in_path[actiondetails]
            filepath = currentpath + "/"  + selectedFile

            print("\nOpened File:", selectedFile)
            open_file(filepath)
            time.sleep(3)

        except:
            print(errorcodes["error404_varFile"])
            time.sleep(2)

        

    elif actiontype == "back":
        try:
            pathBefore = currentpath[:currentpath.rstrip("/").rfind("/") + 1]
            sorted(os.listdir(pathBefore))

            currentpath = pathBefore
            
        except:
            print(errorcodes["error404"])
            time.sleep(2)



    elif actiontype == "rename":
        files_in_path = sorted(os.listdir(currentpath))
        rename_file(files_in_path[actiondetails[0]], actiondetails[1])



    elif actiontype == "changePath":
        newpath = input("Enter new Path ")


        try:
            sorted(os.listdir(newpath))
            currentpath = newpath
        except:
            print(errorcodes["error404"])
            time.sleep(2)
        

        
    elif actiontype == "changeDefaultPath":
        newpath = input("Enter new default Path ")

        if os.path.exists(newpath):
            currentpath = newpath

            with open(default_path_store, "w") as f:
                f.write(currentpath)
        else:
            print(errorcodes["error404"])
            time.sleep(2)



    elif actiontype == "markPath":
        markedPath = currentpath
        print("Path marked")
        time.sleep(2)

    elif actiontype == "marked":
        
        if markedPath != None:
            currentpath = markedPath
        else:
            print(errorcodes["error425"])
            time.sleep(2)
    


    elif actiontype == "add":
        if actiondetails[1] == "folder" or actiondetails[1] == "Folder":
            addFile = create_folder(currentpath, actiondetails[0])

            if addFile == True:
                print(f"\nFolder {actiondetails[0]} was added successfully")
                time.sleep(2)
            else:
                print(errorcodes["error501_varFile"])
                time.sleep(2)
        else:
            addFile = create_file(currentpath, actiondetails[0], actiondetails[1])
            
            if addFile == True:
                print(f"\nFile {actiondetails[0]}.{actiondetails[1]} was added successfully")
                time.sleep(2)
            else:
                print(errorcodes["error501_varFolder"])
                time.sleep(2)

    

    elif actiontype == "delete":
        files_in_path = sorted(os.listdir(currentpath))
        selectedFile = files_in_path[actiondetails]

        deleteFile = delete_file(currentpath, selectedFile)

        if deleteFile == True:
            print(f"{selectedFile} was successfully removed")
            time.sleep(2)

        elif deleteFile == False:
            print("File or Folder could not be deleted")
            time.sleep(2)

        elif deleteFile == 2:
            print("You have no permission to delete folders with content")
            time.sleep(2)
    


    elif actiontype == "copy":
        files_in_path = sorted(os.listdir(currentpath))

        copiedFile = currentpath + "/" + files_in_path[actiondetails[0]]
        copiedFile_Name = files_in_path[actiondetails[0]]
        copiedFile_type = actiondetails[1]

        if copiedFile_type == "file":
            print(f"The file {files_in_path[actiondetails[0]]} was copied. Path: {copiedFile}")
            time.sleep(2)
        else:
            print(f"The folder {files_in_path[actiondetails[0]]} was copied. Path: {copiedFile}")
            time.sleep(2)


    elif actiontype  == "paste":

        if copiedFile != None and copiedFile_Name != None and copiedFile_type != None:
            paste_file(copiedFile, copiedFile_Name, copiedFile_type)

        else:
            print(errorcodes["error424_varFile"])
            time.sleep(2)
    


    elif actiontype == "move":

        if copiedFile != None and copiedFile_Name != None and copiedFile_type != None:
            move_file(copiedFile, copiedFile_Name)

        else:
            print(errorcodes["error424_varFile"])
            time.sleep(2)



    elif actiontype == "extract":
        files_in_path = sorted(os.listdir(currentpath))
        selectedFolder = files_in_path[actiondetails]

        fullpath = os.path.join(currentpath, selectedFolder)
        files_in_fullpath = sorted(os.listdir(fullpath))

        for name in files_in_fullpath:
            
            path_of_selectedFile_in_Folder = fullpath + "/" + name

            extractedStatus = extract_file(path_of_selectedFile_in_Folder, currentpath)

            if extractedStatus == False:
                print(f"The file {name} could not be extracted from the Folder")
    


    elif actiontype == "zip":
        files_in_path = sorted(os.listdir(currentpath))
        selectedFolder = files_in_path[actiondetails[0]]
        
        fullpath = os.path.join(currentpath, selectedFolder)
        createdZip = create_zip(fullpath, actiondetails[1])

        if createdZip == False:
            print(errorcodes["error501_varFile"])
            time.sleep(2)

    elif actiontype == "unzip":
        files_in_path = sorted(os.listdir(currentpath))
        selectedFile = files_in_path[actiondetails]

        zipfile = os.path.join(currentpath, selectedFile)
        unzip_file(zipfile, selectedFile)

        
        


        



    
    
