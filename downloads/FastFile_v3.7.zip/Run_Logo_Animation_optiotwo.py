import tkinter as tk
from PIL import Image, ImageTk
import cv2
import time

class VideoPlayer:
    def __init__(self, video_path):
        self.video_path = video_path
        self.root = tk.Tk()
        self.root.attributes('-fullscreen', True)
        self.root.configure(bg='black')
        self.root.bind('<Escape>', lambda e: self.root.quit())
        
        self.sw = self.root.winfo_screenwidth()
        self.sh = self.root.winfo_screenheight()
        
        self.label = tk.Label(self.root, bg='black')
        self.label.place(relx=0.5, rely=0.5, anchor='center')
        
        self.frames = []
        
    def load_all_frames(self):
        cap = cv2.VideoCapture(self.video_path)
        self.fps = cap.get(cv2.CAP_PROP_FPS) or 60
        
        #print(f"Loading video... Original FPS: {self.fps}")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w = frame.shape[:2]
            
            scale = min(self.sw / w, self.sh / h)
            nw, nh = int(w * scale), int(h * scale)
            frame = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_LINEAR)
            
            img = Image.fromarray(frame)
            self.frames.append(ImageTk.PhotoImage(img))
        
        cap.release()
        #print(f"Loaded {len(self.frames)} frames")
        return self.fps
    
    def play(self):
        video_fps = self.load_all_frames()
        
        if not self.frames:
            print("No frames loaded!")
            self.root.quit()
            return
        
        idx = 0
        delay = int(630 / video_fps)
        start_time = time.time()
        
        #print(f"Playing with {delay}ms delay per frame")
        
        def update():
            nonlocal idx
            
            if idx >= len(self.frames):
                elapsed = time.time() - start_time
                #print(f"Playback finished in {elapsed:.2f}s")
                self.root.after(100, self.root.destroy)
                return
            
            self.label.config(image=self.frames[idx])
            idx += 1
            self.root.after(delay, update)
        
        self.root.after(10, update)
        self.root.mainloop()

def play_video(video_path):
    """Spielt ein Video in Fullscreen ab"""
    player = VideoPlayer(video_path)
    player.play()

if __name__ == "__main__":
    play_video("C:\Schule\Schule_S6\ICT\FastFile\FastFile-Animation.mp4")